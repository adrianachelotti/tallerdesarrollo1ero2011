
Requiere Tomcat y Maven.

Importar en Eclipse el proyecto, a trav�s de File > Import > Existing Projects into workspace.

1) Para activar Maven, bot�n derecho sobre el proyecto > Maven > Enable dependency management
2) Crear una bd llamada "test", y una tabla as�:

	CREATE TABLE person (
	id INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
	firstname VARCHAR(45) NOT NULL,
	lastname VARCHAR(45) NOT NULL,
	PRIMARY KEY(id),
	)

3) Para hacer el deployment, igual que antes, agregarlo a Tomcat a trav�s de Add and remove. Start/Restart server. En el navegador escribir http://localhost:8080/quickstart/