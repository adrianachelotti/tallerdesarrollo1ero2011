This is an example showing how to use Spring Security to secure a webapp.

This project can be built using Maven (http://maven.apache.org).  It can also be imported into 
the Eclipse IDE, but the M2Eclipse plugin should be installed since it is used to resolve 
the classpath.  The project is also setup to use the Spring IDE (http://springide.org).
	
It can also be run from the command line with 'mvn jetty:run' and accessed at the url 
'http://localhost:8080/simple-security'.


Release Notes
--------------
1.1   - Upgraded to Spring 3.0, made project match Simple Form Annotation Config Webapp, 
        and changed login/logout pages to be served through Tiles and be i18n.

1.0.1 - Upgraded to Dynamic Tiles 1.1, Spring 2.5.6, and latest versions of other libraries.

1.0   - Initial release.